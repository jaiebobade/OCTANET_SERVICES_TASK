
document.addEventListener('DOMContentLoaded',function () {
    const button = document.getElementById('myButton');
    button.addEventListener('click', function (){
        alert('Button Clicked!');
    });
});